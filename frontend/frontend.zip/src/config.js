// API URL configuration
// export const API_URL = 'https://blnbtg-backend.thetwlight.xyz/api';
// export const API_URL = 'http://dono-03.danbot.host:4130/api';
export const API_URL = import.meta.env.VITE_API_BASE;